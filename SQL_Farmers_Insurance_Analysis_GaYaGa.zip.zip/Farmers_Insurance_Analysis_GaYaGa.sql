CREATE SCHEMA IF NOT EXISTS ndap;
use ndap;

 CREATE TABLE IF NOT EXISTS FarmersInsuranceData (
     rowID INT PRIMARY KEY,
     srcYear INT,
     srcStateName VARCHAR(255),
     srcDistrictName VARCHAR(255),
     InsuranceUnits INT,
     TotalFarmersCovered INT,
     ApplicationsLoaneeFarmers INT,
     ApplicationsNonLoaneeFarmers INT,
     InsuredLandArea FLOAT,
     FarmersPremiumAmount FLOAT,
     StatePremiumAmount FLOAT,
     GOVPremiumAmount FLOAT,
     GrossPremiumAmountToBePaid FLOAT,
     SumInsured FLOAT,
     PercentageMaleFarmersCovered FLOAT,
     PercentageFemaleFarmersCovered FLOAT,
     PercentageOthersCovered FLOAT,
     PercentageSCFarmersCovered FLOAT,
     PercentageSTFarmersCovered FLOAT,
     PercentageOBCFarmersCovered FLOAT,
     PercentageGeneralFarmersCovered FLOAT,
     PercentageMarginalFarmers FLOAT,
     PercentageSmallFarmers FLOAT,
     PercentageOtherFarmers FLOAT,
     YearCode INT,
     Year_ VARCHAR(255),
     Country VARCHAR(255),
     StateCode INT,
     DistrictCode INT,
     TotalPopulation INT,
     TotalPopulationUrban INT,
     TotalPopulationRural INT,
     TotalPopulationMale INT,
     TotalPopulationMaleUrban INT,
     TotalPopulationMaleRural INT,
     TotalPopulationFemale INT,
     TotalPopulationFemaleUrban INT,
     TotalPopulationFemaleRural INT,
     NumberOfHouseholds INT,
     NumberOfHouseholdsUrban INT,
     NumberOfHouseholdsRural INT,
     LandAreaUrban FLOAT,
     LandAreaRural FLOAT,
     LandArea FLOAT
 );
 
-- ----------------------------------------------------------------------------------------------
-- SECTION 1. 
-- SELECT Queries [5 Marks]

-- 	Q1.	Retrieve the names of all states (srcStateName) from the dataset.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
-- <write your answers in the empty spaces given, the length of solution queries (and the solution writing space) can vary>
select distinct srcStateName
from FarmersInsuranceData;

###

-- 	Q2.	Retrieve the total number of farmers covered (TotalFarmersCovered) 
-- 		and the sum insured (SumInsured) for each state (srcStateName), ordered by TotalFarmersCovered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       sum(TotalFarmersCovered) as Total_Number_Of_Farmers_Covered,
       sum(SumInsured) as Total_Sum_Insured       
from FarmersInsuranceData
group by srcStateName
order by Total_Number_Of_Farmers_Covered desc;

-- ###

-- --------------------------------------------------------------------------------------
-- SECTION 2. 
-- Filtering Data (WHERE) [15 Marks]

-- 	Q3.	Retrieve all records where Year is '2020'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select *
from FarmersInsuranceData
where Year_  = 'Calendar Year (Jan - Dec), 2020';

-- ###

-- 	Q4.	Retrieve all rows where the TotalPopulationRural is greater than 1 million and the srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select *
from FarmersInsuranceData       
where TotalPopulationRural > 1000000 and srcStateName = 'HIMACHAL PRADESH';


-- ###

-- 	Q5.	Retrieve the srcStateName, srcDistrictName, and the sum of FarmersPremiumAmount for each district in the year 2018, 
-- 		and display the results ordered by FarmersPremiumAmount in ascending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       srcDistrictName,
       YearCode,
       sum(FarmersPremiumAmount) as Tot_FarmersPremiumAmount
from FarmersInsuranceData
where YearCode = 2018
group by srcStateName, srcDistrictName
order by Tot_FarmersPremiumAmount;

-- ###

-- 	Q6.	Retrieve the total number of farmers covered (TotalFarmersCovered) and the sum of premiums (GrossPremiumAmountToBePaid) for each state (srcStateName) 
-- 		where the insured land area (InsuredLandArea) is greater than 5.0 and the Year is 2018.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       sum(TotalFarmersCovered) as Tot_num_TotalFarmersCovered,
       sum(GrossPremiumAmountToBePaid) as Tot_GrossPremiumAmountToBePaid
from FarmersInsuranceData
where InsuredLandArea > 5.0 and YearCode = 2018
group by srcStateName;

	  
-- ###
-- ------------------------------------------------------------------------------------------------

-- SECTION 3.
-- Aggregation (GROUP BY) [10 marks]

-- 	Q7. 	Calculate the average insured land area (InsuredLandArea) for each year (srcYear).
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcYear,
       avg(InsuredLandArea) as Avg_InsuredLandArea
from FarmersInsuranceData
group by srcYear;


-- ###

-- 	Q8. 	Calculate the total number of farmers covered (TotalFarmersCovered) for each district (srcDistrictName) where Insurance units is greater than 0.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName,
       sum(TotalFarmersCovered) as Tot_Num_Farmers_Covered
from FarmersInsuranceData
where InsuranceUnits > 0
group by srcDistrictName;


-- ###

-- 	Q9.	For each state (srcStateName), calculate the total premium amounts (FarmersPremiumAmount, StatePremiumAmount, GOVPremiumAmount) 
-- 		and the total number of farmers covered (TotalFarmersCovered). Only include records where the sum insured (SumInsured) is greater than 500,000 (remember to check for scaling).
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       sum(FarmersPremiumAmount) as Tot_FarmersPremiumAmount,
       sum(StatePremiumAmount) as Tot_StatePremiumAmount,
	   sum(GOVPremiumAmount) as Tot_GOVPremiumAmount,
       sum(TotalFarmersCovered) as Tot_TotalFarmersCovered
from FarmersInsuranceData
where SumInsured > 500000
group by srcStateName;


-- ###

-- -------------------------------------------------------------------------------------------------
-- SECTION 4.
-- Sorting Data (ORDER BY) [10 Marks]

-- 	Q10.	Retrieve the top 5 districts (srcDistrictName) with the highest TotalPopulation in the year 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName, 
       TotalPopulation
from FarmersInsuranceData
where YearCode = 2020
order by TotalPopulation desc
limit 5;


-- ###

-- 	Q11.	Retrieve the srcStateName, srcDistrictName, and SumInsured for the 10 districts with the lowest non-zero FarmersPremiumAmount, 
-- 		ordered by insured sum and then the FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       srcDistrictName,
       SumInsured
from FarmersInsuranceData   
where FarmersPremiumAmount != 0
order by SumInsured , FarmersPremiumAmount
limit 10;
       

###

-- 	Q12. 	Retrieve the top 3 states (srcStateName) along with the year (srcYear) where the ratio of insured farmers (TotalFarmersCovered) to the total population (TotalPopulation) is highest. 
-- 		Sort the results by the ratio in descending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

select srcStateName, 
       srcYear, 
       (TotalFarmersCovered / TotalPopulation) as Ratio_of_Total_farmers_cover_to_Total_Popu
from FarmersInsuranceData
order by Ratio_of_Total_farmers_cover_to_Total_Popu desc
limit 3;


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 5.
-- String Functions [6 Marks]

-- 	Q13. 	Create StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select distinct srcStateName, 
       substring(srcStateName, 1, 3) as StateShortName
from FarmersInsuranceData;

-- ###

-- 	Q14. 	Retrieve the srcDistrictName where the district name starts with 'B'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName
from FarmersInsuranceData
where substring(srcDistrictName, 1, 1) = 'B';


-- ###

-- 	Q15. 	Retrieve the srcStateName and srcDistrictName where the district name contains the word 'pur' at the end.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       srcDistrictName
from FarmersInsuranceData
where srcDistrictName regexp 'pur$';


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 6.
-- Joins [14 Marks]

-- 	Q16. 	Perform an INNER JOIN between the srcStateName and srcDistrictName columns to retrieve the aggregated FarmersPremiumAmount for districts where the district’s Insurance units for an individual year are greater than 10.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select 
    f.srcStateName, 
    f.srcDistrictName, 
    SUM(f.FarmersPremiumAmount) as Total_FarmersPremiumAmount
from FarmersInsuranceData f
inner join FarmersInsuranceData d 
on f.srcDistrictName = d.srcDistrictName and f.srcStateName = d.srcStateName
where d.InsuranceUnits > 10
GROUP BY f.srcStateName, f.srcDistrictName;


-- ###

-- 	Q17.	Write a query that retrieves srcStateName, srcDistrictName, Year, TotalPopulation for each district and the the highest recorded FarmersPremiumAmount for that district over all available years
-- 		Return only those districts where the highest FarmersPremiumAmount exceeds 20 crores.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
with HighPremiumDistricts as (
    select 
        srcStateName,
        srcDistrictName,
        YearCode,
        TotalPopulation,
        max(FarmersPremiumAmount) as HighestFarmersPremiumAmount
    from FarmersInsuranceData
    group by  
        srcStateName, 
        srcDistrictName,
        YearCode,
		TotalPopulation
    having 
        max(FarmersPremiumAmount) > 200000000 
) select 
    f.srcStateName,
    f.srcDistrictName,
    f.YearCode,
    f.TotalPopulation,
    h.HighestFarmersPremiumAmount
from FarmersInsuranceData f
inner join HighPremiumDistricts h 
on f.srcStateName = h.srcStateName and f.srcDistrictName = h.srcDistrictName
order by h.HighestFarmersPremiumAmount desc;


-- ###

-- 	Q18.	Perform a LEFT JOIN to combine the total population statistics with the farmers’ data (TotalFarmersCovered, SumInsured) for each district and state. 
-- 		Return the total premium amount (FarmersPremiumAmount) and the average population count for each district aggregated over the years, where the total FarmersPremiumAmount is greater than 100 crores.
-- 		Sort the results by total farmers' premium amount, highest first.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

select f.srcStateName,
	   f.srcDistrictName,
       sum(f.TotalFarmersCovered) as TotalFarmersCovered,
       sum(f.SumInsured) as TotalSumInsured,
       sum(f.FarmersPremiumAmount) as TotalFarmersPremiumAmount,
       avg(f.TotalPopulation) as AverageDistrictPopulation
from FarmersInsuranceData f
left join (select srcStateName,
                  srcDistrictName,
                  avg(TotalPopulation) as AvgPopulation
    from FarmersInsuranceData
    group by srcStateName, srcDistrictName
) p on f.srcStateName = p.srcStateName and f.srcDistrictName = p.srcDistrictName
group by 
    f.srcStateName, 
    f.srcDistrictName
having sum(f.FarmersPremiumAmount) > 1000000000
order by TotalFarmersPremiumAmount desc;

-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 7.
-- Subqueries [10 Marks]

-- 	Q19.	Write a query to find the districts (srcDistrictName) where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName
from FarmersInsuranceData
where TotalFarmersCovered > (
     select avg(TotalFarmersCovered)
     from FarmersInsuranceData
);


-- ###

-- 	Q20.	Write a query to find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >     
select srcStateName
from FarmersInsuranceData
group by srcStateName
having sum(SumInsured) > (
        select sum(SumInsured)
        from FarmersInsuranceData
        where FarmersPremiumAmount = (
                select max(FarmersPremiumAmount)
                from FarmersInsuranceData
                                     )
    );
    
    
-- ###

-- 	Q21.	Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName
from FarmersInsuranceData
where FarmersPremiumAmount > (
        select avg(FarmersPremiumAmount)
        from FarmersInsuranceData
        where srcStateName = (
                select srcStateName
                from FarmersInsuranceData
                group by srcStateName
                order by sum(TotalPopulation) desc
                limit 1
            )
    );



-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 8.
-- Advanced SQL Functions (Window Functions) [10 Marks]

-- 	Q22.	Use the ROW_NUMBER() function to assign a row number to each record in the dataset ordered by total farmers covered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select TotalFarmersCovered,
    row_number() over (order by TotalFarmersCovered desc) as RowNum_TotalFarmersCovered
from FarmersInsuranceData
order by TotalFarmersCovered desc;

-- ###

-- 	Q23.	Use the RANK() function to rank the districts (srcDistrictName) based on the SumInsured (descending) and partition by alphabetical srcStateName.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName,
       srcStateName,
       SumInsured,
       rank() over(partition by srcStateName order by SumInsured desc) as Rank_District_SumInsured
       from FarmersInsuranceData;


-- ###

-- 	Q24.	Use the SUM() window function to calculate a cumulative sum of FarmersPremiumAmount for each district (srcDistrictName), ordered ascending by the srcYear, partitioned by srcStateName.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName,
       srcDistrictName,
       srcYear,
       FarmersPremiumAmount,
       sum(FarmersPremiumAmount)  over(partition by srcStateName, srcDistrictName order by srcYear) as Cumulative_FarmersPremiumAmount
from FarmersInsuranceData;  


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 9.
-- Data Integrity (Constraints, Foreign Keys) [4 Marks]

-- 	Q25.	Create a table 'districts' with DistrictCode as the primary key and columns for DistrictName and StateCode. 
-- 		Create another table 'states' with StateCode as primary key and column for StateName.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
create table districts (
      DistrictCode INT,
      DistrictName VARCHAR(255),
      StateCode INT,
      primary key (DistrictCode)
);

create table States (
    StateCode INT,
    StateName VARCHAR(255),
    primary key (StateCode)
);


-- ###

-- 	Q26.	Add a foreign key constraint to the districts table that references the StateCode column from a states table.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

alter table districts
add constraint fk_StateCode
foreign key (StateCode) references States(StateCode);


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 10.
-- UPDATE and DELETE [6 Marks]

-- 	Q27.	Update the FarmersPremiumAmount to 500.0 for the record where rowID is 1.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
update FarmersInsuranceData
set FarmersPremiumAmount = 500.0
where rowID = 1;


-- ###

-- 	Q28.	Update the Year to '2021' for all records where srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

update FarmersInsuranceData
set srcYear = 2021
where srcStateName = 'HIMACHAL PRADESH';


-- ###

-- 	Q29.	Delete all records where the TotalFarmersCovered is less than 10000 and Year is 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
delete 
from FarmersInsuranceData
where TotalFarmersCovered < 10000 and YearCode = 2020;

-- ###